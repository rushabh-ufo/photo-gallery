import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule } from '@angular/router';

import { MultimediaService } from './multimedia.service';
import { MultimediaComponent } from './multimedia.component';

@NgModule({
    declarations: [
        MultimediaComponent,
    ],
    exports: [
    ],
    imports: [
        BrowserAnimationsModule,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        RouterModule,
    ],
    providers: [
        MultimediaService,
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class MultimediaModule { }
