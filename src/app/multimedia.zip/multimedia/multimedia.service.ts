import { Injectable } from '@angular/core';

@Injectable()
export class MultimediaService {
    hotelId: number = null;
    constructor() {

    }
}
