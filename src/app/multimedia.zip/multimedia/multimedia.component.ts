import { HttpEventType, HttpRequest, HttpResponseBase } from '@angular/common/http';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject, Subscription } from 'rxjs/Rx';
import {
    Component,
    ElementRef,
    OnChanges,
    OnDestroy,
    OnInit,
    SimpleChange,
    SimpleChanges,
    ViewChild,
    ViewEncapsulation,
} from '@angular/core';
import { Router } from '@angular/router';
import { SharedService } from '../core/services/shared.service';
import { CommonService } from '../core/services/common.service';
import { userDetailsParams } from '../shared/consts/shared.constants';
import * as _ from 'lodash';
import { ActivatedRoute } from '@angular/router';
import { MultimediaService } from './multimedia.service';
import { AfterViewInit } from '@angular/core/src/metadata/lifecycle_hooks';
import { LanguageObject } from '../internationalization.constant';

@Component({
    'selector': 'rt-multimedia',
    'templateUrl': './multimedia.component.html'
})

export class MultimediaComponent implements OnInit, AfterViewInit, OnDestroy {
    public showLoader: boolean = false;
    public loadPage: boolean = false;
    public operationsAllowed: any = null;
    public notificationMessage: any;
    private propertyBaseInfo: any;
    public itemMarkedForDeletion: any;
    private userPermissionCode = 98;
    public errorObject: object = {};
    public extrasList: any[] = [];
    public roomTypeList: any[] = [];
    public attractionsList: any[] = [];
    private apiLoadCount: number = 0;
    private apiLoadCountSubject: BehaviorSubject<number>;
    private apiCountSubscription: Subscription;
    public imagesArray: any[] = [];
    public selectedImages: any[] = [];
    public selectedEntity: string = null;
    public sidePanelElements: any[] = [];
    public sidePanelElementsClone: any[] = [];
    public filterValue: string;
    public selectedEntityId: number = -1;
    public selectedEntityName: string = '';
    public hotelName: string;
    public hotelId: number;
    public propertiesList: any[] = [];
    public hotelObject: object = {};
    public showInnerLoader: boolean = false;
    private extrasListMain: any[] = [];
    public roomTypeListMain: any[] = [];
    public attractionsListMain: any[] = [];
    public savedImages = [];
    public uploadCompleteCount = 0;
    public newImages = [];
    public showFileUploader: boolean = false;
    public languageObject: object = LanguageObject;
    public showNotification: boolean = false;
    public currentUploadCount: number = 0;
    @ViewChild('errorBtn') errorBtn: ElementRef;
    public errorB;

    constructor(private appService: AppService,
        private router: Router,
        public sharedService: SharedService,
        private commonService: CommonService,
        private http: HttpClient,
        private route: ActivatedRoute,
        private multimediaService: MultimediaService) {
        this.constructorFn();
    }
    constructorFn() {
        this.languageObject = this.commonService.getLanguageData();
        // console.log('Hotel Id: ', this.multimediaService['hotelId']);
        this.route.queryParams.subscribe(params => {
            if (params['hotel_id']) {
                this.multimediaService['hotelId'] = Number(params['hotel_id']);
                // console.log('Hotel Id: ', this.multimediaService['hotelId']);
                this.commonService.loadPropertyBaseInfo(<Component>this, 'loadSidePanel', null);
                // this.loadSidePanel();
            }
        });
        this.apiCountSubscription = this.apiLoadCountSubject.subscribe((updateCount) => {
            this.apiLoadCount++;
            // console.log('load count : ', this.apiLoadCount);
            if (this.apiLoadCount === 3) {
                // console.log('marking show loader false');
                // this.formatSidepanelArray();
                this.loadPage = true;
            }
        }, error => {
            console.log('error: ', error);
            this.loadPage = true;
        });
    }

    ngAfterViewInit() {
        this.errorB = this.errorBtn.nativeElement as HTMLElement;
    }

    ngOnInit() {

    }

    ngOnDestroy() {

        this.operationsAllowed = null;
        this.notificationMessage = null;
        this.propertyBaseInfo = null;
        this.itemMarkedForDeletion = null;
        this.userPermissionCode = null;
        this.errorObject = null;
        this.extrasList = null;
        this.roomTypeList = null;
        this.attractionsList = null;
        this.apiLoadCount = null;
        this.apiLoadCountSubject = null;
        this.apiCountSubscription = null;
        this.imagesArray = null;
        this.selectedImages = null;
        this.selectedEntity = null;
        this.sidePanelElements = null;
        this.sidePanelElementsClone = null;
        this.filterValue = null;
        this.selectedEntityId = null;
        this.selectedEntityName = null;
        this.hotelName = null;
        this.hotelId = null;
        this.propertiesList = null;
        this.hotelObject = null;
        this.extrasListMain = null;
        this.roomTypeListMain = null;
        this.attractionsListMain = null;
        this.savedImages = null;
        this.uploadCompleteCount = null;
        this.newImages = null;
        this.languageObject = null;
        this.currentUploadCount = null;
        this.errorBtn = null;
        this.errorB = null;
    }

    // public formatSidepanelArray() {
    //     this.populateSidePanleArray('roomTypeList', 'room', 'Rooms');
    //     this.populateSidePanleArray('extrasList', 'extra', 'Extras');
    //     this.populateSidePanleArray('attractionsList', 'attraction', 'Attractions');
    //     this.sidePanelElementsClone = _.cloneDeep(this.sidePanelElements);
    // }

    // private populateSidePanleArray(listName, type, topLevelName) {
    //     for (let i = 0; i < this[listName].length; i++) {
    //         if (i === 0) {
    //             const topLevelObj = {
    //                 Name: topLevelName,
    //                 Level: 1,
    //                 UID: -1,
    //                 Type: type,
    //             };
    //             this.sidePanelElements.push(topLevelObj);
    //         }
    //         const tempRoomType = this[listName][i];
    //         tempRoomType['Level'] = 2;
    //         tempRoomType['Type'] = type;
    //         this.sidePanelElements.push(tempRoomType);
    //     }
    // }

    public loadSidePanel() {
        this.hotelName = this.sharedService.getPersistentObject('hotelBaseInfo')['PropertyName'];
        this.hotelId = this.sharedService.getPersistentObject('hotelBaseInfo')['PropertyId'];
        this.hotelObject['UID'] = this.hotelId;
        this.hotelObject['Name'] = this.hotelName;
        this.propertiesList.push(this.hotelName);
        // call APIs to populate side panel
        // console.log('Property Id: ', propertyConstants.propertyId);
        const extrasRequestParam = {
            'PropertyUIDs': [propertyConstants.propertyId],
            'Fields': ['Name', 'UID'],
        };
        // calling for extras
        this.loadPage = false;
        this.appService.performRequest(appUrls.httpMethods.POST, appUrls.propertyManagement.listExtras, extrasRequestParam).subscribe(resp => {
            if (resp['Errors'].length > 0) {
                this.errorObject = resp['Errors'][0];
                this.apiLoadCountSubject.error(1);
                this.errorB.click();
                return;
            }
            this.extrasList = resp['Result'];
            this.extrasListMain = resp['Result'];
            this.apiLoadCountSubject.next(1);
        }, error => {
            this.errorObject = {
                ErrorType: error.statusText,
                ErrorCode: error.status,
                Description: error.error && error.error.Message
            };
            this.apiLoadCountSubject.error(1);
            this.errorB.click();
        });

        // calling for roomTypes
        const roomTypeRequestParam = {
            'PropertyIds': [propertyConstants.propertyId],
            'Fields': ['Name', 'UID'],
        };
        this.appService.performRequest(appUrls.httpMethods.POST, appUrls.propertyManagement.listRoomtypes, roomTypeRequestParam).subscribe(resp => {
            if (resp['Errors'].length > 0) {
                this.errorObject = resp['Errors'][0];
                this.apiLoadCountSubject.error(1);
                this.errorB.click();
                return;
            }
            this.roomTypeList = resp['Results'];
            this.roomTypeListMain = resp['Results'];
            this.apiLoadCountSubject.next(2);

        }, error => {
            this.errorObject = {
                ErrorType: error.statusText,
                ErrorCode: error.status,
                Description: error.error && error.error.Message
            };
            this.apiLoadCountSubject.error(1);
            this.errorB.click();
        });
    }

    public filterSidePanel() {
        if (this.filterValue === '') {
            this.roomTypeList = _.cloneDeep(this.roomTypeListMain);
            this.extrasList = _.cloneDeep(this.extrasListMain);
            this.hotelName = this.hotelObject['Name'];
        } else {
            this.roomTypeList = this.roomTypeListMain.filter(element => {
                return element['Name'].toLowerCase().includes(this.filterValue.toLowerCase());
            });
            this.extrasList = this.extrasListMain.filter(element => {
                return element['Name'].toLowerCase().includes(this.filterValue.toLowerCase());
            });
            if (this.hotelObject['Name'].indexOf(this.filterValue) !== -1) {
                this.hotelName = this.hotelObject['Name'];
            } else {
                this.hotelName = null;
            }
        }

    }

    public clearSearch() {
        this.filterValue = '';
        this.roomTypeList = _.cloneDeep(this.roomTypeListMain);
        this.extrasList = _.cloneDeep(this.extrasListMain);
        this.hotelName = this.hotelObject['Name'];
    }

    public loadImages(currentObj, type) {
        const requestParam = {
            'PropertyIds': [propertyConstants.propertyId],
            'RequestId': this.sharedService.guid(),
            'LanguageUID': 1,
            'RuleType': 'Omnibees'
        };
        let requestUrl = appUrls.propertyManagement.listPropertiesImages;
        this.selectedEntity = 'Property';
        this.selectedEntityName = this.hotelName;
        if (type === 'room') {
            requestParam['RoomTypeIds'] = [currentObj['UID']];
            requestUrl = appUrls.propertyManagement.listRoomTypeImages;
            this.selectedEntity = 'RoomType';
            this.selectedEntityName = currentObj['Name'];
        }
        if (type === 'extra') {
            requestParam['ExtrasIds'] = [currentObj['UID']];
            requestUrl = appUrls.propertyManagement.listExtrasImages;
            this.selectedEntity = 'Extra';
            this.selectedEntityName = currentObj['Name'];
        }
        if (type === 'attraction') {
            requestParam['AttractionIds'] = [currentObj['UID']];
            requestUrl = appUrls.propertyManagement.listAttractionsImages;
            this.selectedEntity = 'Attraction';
            this.selectedEntityName = currentObj['Name'];
        }
        // this.loadPage = false;
        this.showInnerLoader = true;
        this.selectedEntityId = currentObj['UID'];
        this.appService.performRequest(appUrls.httpMethods.POST, requestUrl, requestParam).subscribe(resp => {
            if (resp['Errors'].length > 0) {
                this.errorObject = resp['Errors'][0];
                // this.loadPage = true;
                this.showInnerLoader = false;
                this.errorB.click();
                return;
            }
            this.imagesArray = [];
            if (resp['Result'] && resp['Result'] !== null) {
                this.imagesArray = resp['Result'];
                if (this.imagesArray.length > 0) {
                    for (let i = 0; i < this.imagesArray.length; i++) {
                        this.imagesArray[i]['previewLink'] = this.imagesArray[i]['ImageLink'] + '&sizeCat=Preview';
                    }
                }
            }
            // this.loadPage = true;
            this.showInnerLoader = false;
        }, error => {
            this.errorObject = {
                ErrorType: error.statusText,
                ErrorCode: error.status,
                Description: error.error && error.error.Message
            };
            // this.loadPage = true;
            this.showInnerLoader = false;
            this.errorB.click();
        });

    }

    public habdleImageAdded(images) {
        this.imagesArray = images;
        // console.log('Inside handle Image add: ', this.imagesArray);
        this.saveImages();
    }

    public handleSelectAll(event) {
        this.selectedImages = event;
    }

    public handleUnselectAll() {
        this.selectedImages = [];
    }

    public handleImageSelected(event) {
        this.selectedImages = [];
        this.selectedImages = event;
        // console.log('Image selected: ', this.selectedImages);
    }

    public handleMainImage(event) {
        // console.log(event);
        const requestParam = {
            'Key': event,
            'RequestId': this.sharedService.guid(),
            'LanguageUID': 1,
            'RuleType': 'Omnibees'
        };
        this.showLoader = true;
        this.appService.performRequest(appUrls.httpMethods.POST, appUrls.propertyManagement.updateFavouriteImage, requestParam).subscribe(resp => {
            if (resp['Errors'].length > 0) {
                this.errorObject = resp['Errors'][0];
                this.showLoader = false;
                this.errorB.click();
                return;
            }
            this.showLoader = false;
        }, error => {
            this.errorObject = {
                ErrorType: error.statusText,
                ErrorCode: error.status,
                Description: error.error && error.error.Message
            };
            this.showLoader = false;
            this.errorB.click();
        });
    }

    public handleImageDelete(event) {
        this.imagesArray = [];
        this.imagesArray = event;
        // console.log(this.imagesArray);
        const requestParam = {
            'RequestId': this.sharedService.guid(),
            'LanguageUID': 1,
            'RuleType': 'Omnibees',
            'Includeresult': true
        };
        let requestUrl = '';
        let itemsDeleted = 0;
        if (this.imagesArray.length > 1) {
            requestUrl = appUrls.propertyManagement.deleteMultimediaImageBulk;
            const keysArray = [];
            // for (let i = 0; i < this.imagesArray.length; i++) {
            //     if (this.imagesArray[i]['IsDeleted'] === true) {
            //         keysArray.push(this.imagesArray[i]);
            //     }
            // }
            requestParam['Keys'] = this.imagesArray;
            itemsDeleted = this.imagesArray.length;
        } else {
            requestUrl = appUrls.propertyManagement.deleteMultimediaImage;
            requestParam['Key'] = this.imagesArray[0];
            itemsDeleted = 1;
        }
        this.showLoader = true;
        this.appService.performRequest(appUrls.httpMethods.POST, requestUrl, requestParam).subscribe(resp => {
            if (resp['Errors'].length > 0) {
                this.errorObject = resp['Errors'][0];
                this.showLoader = false;
                this.errorB.click();
                return;
            }
            this.showLoader = false;
            this.notificationMessage = {
                message: itemsDeleted + ' Photos Deleted Successfully',
                isDismissible: true,
                icon: 'checkmark',
                type: 'success'
            };
            this.showNotification = true;
        }, error => {
            this.errorObject = {
                ErrorType: error.statusText,
                ErrorCode: error.status,
                Description: error.error && error.error.Message
            };
            this.showLoader = false;
            this.errorB.click();
        });
    }

    public saveImages(event?) {
        this.newImages = [];
        let requestUrl = '';
        this.currentUploadCount++;
        for (let i = 0; i < this.imagesArray.length; i++) {
            if (this.imagesArray[i]['NewAdded']) {
                this.imagesArray[i]['PropertyId'] = propertyConstants.propertyId;
                this.imagesArray[i]['EntityKey'] = this.selectedEntityId;

                // if (this.imagesArray[i]['uploadStatus'] === undefined) {
                this.imagesArray[i]['uploadStatus'] = 'uploading';
                this.newImages.push(this.imagesArray[i]);
                // }

            }
        }
        const insertImageRequest = {
            'RequestId': '',
            'RuleType': 'Omnibees',
            'LanguageUID': 1,
            'IncludeResult': true
        };

        for (let i = 0; i < this.newImages.length; i++) {
            if (this.savedImages.indexOf(this.newImages[i]['TrackingId']) === -1) {
                this.showFileUploader = true;
                this.savedImages.push(this.newImages[i]['TrackingId']);
                insertImageRequest['Item'] = this.newImages[i];
                requestUrl = appUrls.propertyManagement.insertMultimediaImages;
                insertImageRequest['TrackingId'] = this.newImages[i]['TrackingId'];
                insertImageRequest['RequestId'] = this.newImages[i]['TrackingId'];

                this.appService.performRequestWithProgress(appUrls.httpMethods.POST, requestUrl, insertImageRequest).subscribe(resp => {
                    // Via this API, you get access to the raw event stream.
                    // Look for upload progress events.
                    if (resp.type === HttpEventType.UploadProgress) {
                        // This is an upload progress event. Compute and show the % done:
                        const percentDone = Math.round(100 * resp.loaded / resp.total);
                        // console.log(`File is ${percentDone}% uploaded.`);
                    } else if (resp instanceof HttpResponseBase) {
                        // console.log('upload Event: ', JSON.stringify(resp));
                        if (resp.hasOwnProperty('body')) {
                            if (resp['body']['Errors'].length > 0) {
                                this.errorObject = resp['body']['Errors'][0];
                                this.showFileUploader = false;
                                const index = _.findIndex(this.imagesArray, function (o) { return o['TrackingId'] === resp['body']['Errors'][0]['TrackingId']; });
                                this.imagesArray.splice(index, 1);
                                this.currentUploadCount--;
                                this.errorB.click();
                                return;
                            }
                            const requestId = resp['body']['RequestId'];
                            for (let j = 0; j < this.imagesArray.length; j++) {
                                if (this.imagesArray[j]['TrackingId'] === requestId && resp['body']['Errors'].length === 0 && (resp['status'] >= 200 && resp['status'] <= 299)) {
                                    this.imagesArray[j]['uploadStatus'] = 'success';
                                    this.imagesArray[j]['Id'] = resp['body']['Result']['Id'];
                                    this.uploadCompleteCount++;
                                    this.checkLoaderStatus();
                                }
                                if (this.imagesArray[j]['TrackingId'] === requestId && resp['body']['Errors'].length > 0 && resp['status'] >= 400) {
                                    this.imagesArray[j]['uploadStatus'] = 'fail';
                                    this.uploadCompleteCount++;
                                    this.checkLoaderStatus();
                                }
                            }
                        }
                        // console.log('File is completely uploaded!');
                    }
                });
            }

        }
    }

    public refreshview() {
        this.selectedEntity = null;
        this.imagesArray = [];
        this.selectedEntityId = null;
    }

    public checkLoaderStatus() {
        if (this.currentUploadCount === this.uploadCompleteCount) {
            console.log('upload finished');
            this.showFileUploader = false;
            const message = this.uploadCompleteCount + ' photos successfully updated';
            this.notificationMessage = {
                message: message,
                isDismissible: true,
                icon: 'checkmark',
                type: 'success'
            };
            this.showNotification = true;
            this.currentUploadCount = 0;
            // this.newImages = [];
            this.uploadCompleteCount = 0;
        }
    }
    public closeNotification() {
        this.showNotification = false;
    }
    public setModalPreference(this, data) {
        this.commonService.setModalPreference(this, data);
    }
    public clearErrorObject() {
        this.errorObject = {};
    }
}
